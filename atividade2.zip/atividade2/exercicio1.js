var numero1 = 3;
var numero2 = 5;
var resultado;

resultado = numero1 + numero2;

console.log("Resultado da operação de soma do resultado entre numero1 e numero2 = " + resultado);

resultado = numero1/numero2;

console.log("Resultado da operação de divisao do resultado entre numero1 e numero2 = " + resultado);

resultado = numero1*numero2;

console.log("Resultado da operação de multiplicacao do resultado entre numero1 e numero2 = " +  resultado);