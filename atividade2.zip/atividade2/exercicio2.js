function createMatrix(rows, cols) {
    const matrix = [];
    for (let i = 0; i < rows; i++) {
        matrix.push([]);
        for (let j = 0; j < cols; j++) {
            matrix[i].push(Math.floor(Math.random() * 10)); // Preenche com valores aleatórios de 0 a 9
        }
    }
    return matrix;
}

function transposeMatrix(matrix) {
    const transposed = [];
    const rows = matrix.length;
    const cols = matrix[0].length;

    for (let j = 0; j < cols; j++) {
        transposed.push([]);
        for (let i = 0; i < rows; i++) {
            transposed[j].push(matrix[i][j]);
        }
    }
    return transposed;
}

function printMatrix(matrix) {
    for (let i = 0; i < matrix.length; i++) {
        console.log(matrix[i].join('\t'));
    }
}

const rows = 3; // Número de linhas
const cols = 4; // Número de colunas

console.log("Matriz A:");
const matrixA = createMatrix(rows, cols);
printMatrix(matrixA);

console.log("\nMatriz Transposta:");
const transposedMatrix = transposeMatrix(matrixA);
printMatrix(transposedMatrix);
