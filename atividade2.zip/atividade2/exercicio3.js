function multiplyMatrices(matrixA, matrixB) {
    const rowsA = matrixA.length;
    const colsA = matrixA[0].length;
    const rowsB = matrixB.length;
    const colsB = matrixB[0].length;

    if (colsA !== rowsB) {
        console.log("Não é possível calcular. O número de colunas da matriz A deve ser igual ao número de linhas da matriz B.");
        return;
    }

    const resultMatrix = new Array(rowsA);

    for (let i = 0; i < rowsA; i++) {
        resultMatrix[i] = new Array(colsB);
        for (let j = 0; j < colsB; j++) {
            resultMatrix[i][j] = 0;
            for (let k = 0; k < colsA; k++) {
                resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }

    return resultMatrix;
}

const matrixA = [
    [2, 3],
    [4, 1]
];

const matrixB = [
    [5, 7],
    [6, 8]
];

console.log("Matriz A:");
console.log(matrixA);

console.log("\nMatriz B:");
console.log(matrixB);

const resultMatrix = multiplyMatrices(matrixA, matrixB);
if (resultMatrix) {
    console.log("\nMatriz Resultante C = AxB:");
    console.log(resultMatrix);
}
